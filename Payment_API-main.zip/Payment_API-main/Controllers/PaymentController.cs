using CEDPaymentAPI.Models;
using Newtonsoft.Json;
using RestSharp;
using Stripe;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Results;

namespace CEDPaymentAPI.Controllers
{
    public class PaymentController : ApiController
    {
        public StripeKeys GetPublicKey()
        {
            StripeKeys keyModel = new StripeKeys();
            keyModel.PublicKeys = "pk_live_51IArzPJtt4LpGWT43UYQrGhASKMEgJskCEsa81dTOkeRE1RFxlSBnuxwPWIt0nHUHPxx9obqxiXEuAgJcCELoEBj002xL23rR8";
            return keyModel;
        }
        
        [HttpPost]
        public IHttpActionResult CreateStripeTransaction([FromBody] Models.StripeRequest model)
        {
        
            string connectAccountId = "";
            ////// Start Code for Secret Key and Connect account ID assignment //////
            connectAccountId = "acct_1IArzPJtt4LpGWT4";
            StripeConfiguration.ApiKey = "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";
            ////// End Code for Secret Key and Connect account ID assignment //////
            
            
            ////// Start Code for setup values testing and assignment //////
            string customerName = model.FirstName + " " + model.LastName;
            
            if (string.IsNullOrEmpty(model.Payment_Method_Id)){
                return Json(new { error = "Payment_Method_Id is not provided!" });
            }
            else if (string.IsNullOrEmpty(customerName)){
                return Json(new { error = "Provide customer name!" });
            }
            else if (model.Amount <= 0){
                return Json(new { error = "Amount should be greater than 0!" });
            }
            
            PaymentIntent paymentIntent = null;
            ConfirmPaymentRequest request = new ConfirmPaymentRequest();
            request.PaymentMethodId = model.Payment_Method_Id;
            int chargeAmount = 0;
            chargeAmount = Convert.ToInt32(model.Amount);
            string currency = "usd", description = "";
            currency = ConfigurationManager.AppSettings["StripeCurrency"];
            ////// End Code for setup values testing and assignment //////
            
            
            ////// Start of Code for Customer Creation //////
            var options = new CustomerCreateOptions
            {
                 Email = model.Email,
                 Description = Convert.ToString(model.Amount / 100),
                 Name = model.FirstName + " " + model.LastName,
                 Phone = model.Phone,
                 Address = new AddressOptions {
                    City = model.City,
                    Country = model.Country,
                    State = model.State,
                    Line1 = model.Address1,
                 },
                 Metadata = new Dictionary<String, String> {
                    {"ZipCode", model.ZipCode},
                 }
            };
            var service = new CustomerService();
            var cus_Id = service.Create(options);
            // return Json(new { error = cus_Id.Id });
            ////// End of Code for Customer Creation //////
            
            
            ////// Start Code for payment Intent creation setup values testing and assignment //////
            try
            {
                if (model.Amount > 0)
                {
                    description = "Donation -- $" + Convert.ToString(model.Amount / 100) + " -- " + customerName + " -- " + model.Email + " -- " + model.Phone + " -- " + model.City + " -- " + model.State + " -- " + model.Country + " -- " + model.ZipCode + " -- " + model.Address1;
                }
            }catch(Exception xxxxxx)
            {
                description = "Donation -- $ -- " + customerName + " -- " + model.Email;
            }
            
            if (string.IsNullOrEmpty(connectAccountId))
            {
                return Json(new { error = "No Connect Account User Credentials exist!" });
            }
            
            string fullName = customerName;
            if (fullName.Length >= 18)
                fullName = fullName.Substring(0, 18);
            
            var paymentIntentService = new PaymentIntentService();
            
            try
            {
                if (request.PaymentMethodId != null)
                {
                    // Create the PaymentIntent
                    var createOptions = new PaymentIntentCreateOptions
                    {
                        ReceiptEmail = model.Email,
                        PaymentMethod = request.PaymentMethodId,
                        Amount = chargeAmount,
                        Description = description,
                        Metadata = new Dictionary<string, string>
                                {
                          { "customer", description },
                                },
                        Currency = currency,
                        ConfirmationMethod = "manual",
                        PaymentMethodTypes = new List<string> { "card" },
                        Customer = cus_Id.Id,
                        StatementDescriptorSuffix = fullName,
//                         TransferData = new PaymentIntentTransferDataOptions
//                         {
//                             //Amount = fee,
//                             Destination = connectAccountId,
//                         },
                        Confirm = true,
                    };
                    paymentIntent = paymentIntentService.Create(createOptions);
                }
                else
                {
                    return Json(new { error = "Payment_Method_Id is not provided!" });
                }

            }
            catch (StripeException e)
            {
                return Json(new { error = e.StripeError.Message });
            }
            ////// End Code for payment Intent creation setup values testing and assignment //////
            
            
            return generatePaymentResponse(paymentIntent);
        }
        
        ////// Start Code for Generating Payment response //////
        private IHttpActionResult generatePaymentResponse(PaymentIntent intent)
        {
            // Note that if your API version is before 2019-02-11, 'requires_action'
            // appears as 'requires_source_action'.
            if (intent.Status == "requires_action" &&
                intent.NextAction.Type == "use_stripe_sdk")
            {
                // Tell the client to handle the action
                return Json(new
                {
                    requires_action = true,
                    payment_intent_client_secret = intent.ClientSecret
                });
            }
            else if (intent.Status == "succeeded")
            {
                // The payment didn’t need any additional actions and completed!
                // Handle post-payment fulfillment
                return Json(new { success = true });
            }
            else
            {
                // Invalid status
                return Json(new { success = false });
                //return StatusCode(500, new { error = "Invalid PaymentIntent status" });
            }
        }
        ////// End Code for Generating Payment response //////
        
        ////// Start Code for Confirming Payment response //////
        public IHttpActionResult ConfirmPayment(String payment_intent_id)
        {

            ConfirmPaymentRequest request = new ConfirmPaymentRequest();
            request.PaymentIntentId = payment_intent_id;

            var paymentIntentService = new PaymentIntentService();
            PaymentIntent paymentIntent = null;
            try
            {
                if (request.PaymentIntentId != null)
                {
                    var confirmOptions = new PaymentIntentConfirmOptions { };
                    paymentIntent = paymentIntentService.Confirm(
                        request.PaymentIntentId,
                        confirmOptions
                    );

                }
            }
            catch (StripeException e)
            {
                return Json(new { error = e.StripeError.Message });
            }
            return generatePaymentResponse(paymentIntent);
        }
        ////// Start Code for Confirming Payment response //////
        
        
    }
    
    public class ConfirmPaymentRequest
    {
        [JsonProperty("payment_method_id")]
        public string PaymentMethodId { get; set; }

        [JsonProperty("payment_intent_id")]
        public string PaymentIntentId { get; set; }
    }

    
    //////////////////////////////////////////////////////////
    
}
