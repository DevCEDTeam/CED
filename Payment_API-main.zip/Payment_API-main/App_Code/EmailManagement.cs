﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;

namespace CEDPaymentAPI.App_Code
{
    public class EmailManagement
    {
        public static string SendEmail(string toEmail, string subject, string body, string ccEmail = "'")
        {
            string result = "0";
            string SMTP_SERVER = System.Configuration.ConfigurationManager.AppSettings["SMTPServer"];
            string smptLogin = System.Configuration.ConfigurationManager.AppSettings["SMTPLogin"];
            string password = System.Configuration.ConfigurationManager.AppSettings["SMTPPassword"];
            string SMTPEmailFrom = System.Configuration.ConfigurationManager.AppSettings["SMTPFromEmail"];
            string SMTP_Port = System.Configuration.ConfigurationManager.AppSettings["SMTPPort"];
            string FromEmailTitle = System.Configuration.ConfigurationManager.AppSettings["FromEmailTitle"];
            int SMTPPortNo = 25;
            if (SMTP_Port != "")
                SMTPPortNo = Convert.ToInt32(SMTP_Port);

            MailMessage message = new MailMessage();
            message.IsBodyHtml = true;
            message.From = new MailAddress(SMTPEmailFrom, FromEmailTitle);
            message.To.Add(new MailAddress(toEmail));
            if (!string.IsNullOrEmpty(ccEmail))
            {
                message.CC.Add(new MailAddress(ccEmail));
            }
            message.Subject = subject;
            message.Body = body;

            using (var client = new System.Net.Mail.SmtpClient(SMTP_SERVER, SMTPPortNo))
            {
                // Pass SMTP credentials
                client.Credentials =
                    new NetworkCredential(smptLogin, password);

                // Enable SSL encryption
                client.EnableSsl = true;

                // Try to send the message. Show status in console.
                try
                {
                    client.Send(message);
                    result = "1";
                }
                catch (Exception ex)
                {
                    result = ex.Message;
                }
            }

            return result;
        }
    }
}